var express = require('express');
var router = express.Router();
const imcController = require('../Controllers/imcController');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Calcular IMC' });
});
router.post('/calcular', imcController.calcular);

module.exports = router;
