const Galeria = require('../models/galeria');

exports.show = (req, res) => {
    Galeria.findAll()
    .then((resultados) => {
        res.render('galeria', {
            title: 'Galeria',
            galeria: resultados,
        });
    })
    .catch((err) => console.log(err));
};

exports.add = (req, res) => {
    var foto = req.body.foto;
    Galeria.create({
        foto: foto
    })
    .then((resultados) => {
        res.redirect('/galeria');
    })
    .catch((err) => console.log(err));
};