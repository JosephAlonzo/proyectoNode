var express = require('express');
var router = express.Router();
const galeriaController = require('../Controllers/galeriaController');

/* GET galeria page. */

router.get('/', galeriaController.show);
router.post ('/galeria/add', galeriaController.add);


module.exports = router;
