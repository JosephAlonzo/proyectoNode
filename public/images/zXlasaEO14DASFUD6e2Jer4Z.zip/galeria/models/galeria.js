const { Sequelize } = require('sequelize');

const sequelize = require('../conexion/database');

const Galeria = sequelize.define('galeria', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    allowNull: false,
    primaryKey: true,
  },
  foto: Sequelize.STRING
});

module.exports = Galeria;
