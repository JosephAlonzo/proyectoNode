const Users = require('../models/user');

exports.get = (req, res) => {
    Users.findAll()
    .then((resultados) => {
        console.log(resultados);
        res.render('users', {
            title: 'Usuarios',
            users: resultados,
        });
    })
    .catch((err) => console.log(err));
};

exports.add = (req, res) => {
    var nombre = req.body.nombre;
    var apellidos = req.body.apellidos;
    var foto = req.body.foto;
    var sexo = req.body.sexo;
    
    console.log(req.body);
    Users.create({
        nombre: nombre,
        apellidos: apellidos,
        foto: foto,
        sexo: sexo,
    })
    .then((result) => {
        console.log(result);
        res.redirect('/users');
    })
    .catch((err) => console.log(err));
};


exports.updateget = (req, res) => {
    var id = req.params.id;
    Users.findByPk(id)
        .then((user) => {
            res.render('edit-user', {
                title: 'Usuarios',
                user: user,
            });
        })
        .catch((err) => console.log(err));
};


exports.update = (req, res) => {
    var id = req.body.id;
    var nombre = req.body.nombre;
    var apellidos = req.body.apellidos;
    var foto = req.body.foto;
    var sexo = req.body.sexo;

    Users.findByPk(id)
        .then((user) => {
            user.nombre= nombre,
            user.apellidos= apellidos,
            user.foto= foto,
            user.sexo= sexo
            return user.save();
        })
        .then((reponse) => {
            res.redirect('/users');
        })
        .catch((err) => console.log(err));
};



exports.delete = (req, res) => {
    var id = req.params.id;

    Users.findByPk(id)
        .then((user) => {
            return user.destroy(id);
        })
        .then((result) => {
            res.redirect('/users');
        })
        .catch((err) => console.log(err));
};
