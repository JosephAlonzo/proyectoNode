var express = require('express');
var router = express.Router();

const userController = require('../Controllers/userController');

router.get('/', userController.get);
router.get('/users', userController.get);

router.get('/add', function(req, res, next) {
  res.render('add-user', { title: 'agregar usuario' });
});
router.post('/add', userController.add);

router.get('/update/:id', userController.updateget);
router.post('/update', userController.update);

router.get('/delete/:id', userController.delete);


module.exports = router;
